package Practica_1_1;

public class MyFirstApp {
	
	public static void main(String[] args) {
		System.out.println("I rule!");
		System.out.println("The World");
	}
}
